import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomUUID} from 'node:crypto';
import {syncDispatch} from './sync.mjs';
const exec = promisify(execFile);
async function git(root, args, options={}) {
  try { const job=exec('git', ['-C', root, ...args], {windowsHide:true, timeout:120000,maxBuffer:8*1024*1024,env:{...process.env,GIT_TERMINAL_PROMPT:'0',GIT_LITERAL_PATHSPECS:args[0]==='check-ignore'?'0':'1'}});job.child.stdin.end(options.input||'');return (await job).stdout; }
  catch(e) { if(options.allowExit1&&e.code===1)return e.stdout||'';throw new Error(e.stderr?.trim() || e.message); }
}
async function rootOf(input) {
 const root = await fs.realpath(input);
 const top = await fs.realpath((await git(root,['rev-parse','--show-toplevel'])).trim());
 if(root.toLowerCase() !== top.toLowerCase()) throw Error('Abre la carpeta raíz del repositorio.');
 return top;
}
async function safe(root, relative, allowRoot=false) {
 if(typeof relative !== 'string' || path.isAbsolute(relative) || relative.includes(':') || relative.split(/[\\/]/).some(x=>x==='..'||x.toLowerCase()==='.git'||/[. ]$/.test(x)||/[<>"|?*\x00-\x1f]/.test(x)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(x))) throw Error('Ruta no permitida.');
 const parts=relative.split(/[\\/]/).filter(Boolean);
 if(!parts.length && !allowRoot) throw Error('Selecciona un archivo o carpeta.');
 let current=root;
 for(let i=0;i<parts.length;i++) {
  current=path.join(current,parts[i]);
  try { const stat=await fs.lstat(current); if(stat.isSymbolicLink()) throw Error('Los enlaces simbólicos no se pueden gestionar.'); if(i<parts.length-1 && !stat.isDirectory()) throw Error('Ruta inválida.'); }
  catch(e) { if(e.code!=='ENOENT') throw e; }
 }
 return current;
}
async function changes(root) {
 const raw=await git(root,['status','--porcelain=v1','-z','--untracked-files=all']);
 const records=raw.split('\0'), result=[];
 for(let i=0;i<records.length;i++) {const r=records[i]; if(!r)continue; const status=r.slice(0,2), p=r.slice(3); const old=/R|C/.test(status)?records[++i]:undefined; result.push({path:p,status,old});}
 return result;
}
async function clean(root) {if((await changes(root)).length)throw Error('Guarda tus cambios en un commit antes de cambiar de rama o descargar.');}
const pad=n=>String(n).padStart(2,'0');
export function stamp(d=new Date(),time=true){const day=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;return time?`${day} ${pad(d.getHours())}:${pad(d.getMinutes())}`:day;}
export const autoMessage=()=> 'Respaldo automático · '+stamp();
function identityError(e){if(/tell me who you are|user\.(name|email)|empty ident/i.test(e.message))throw Error('Configura tu nombre y correo de Git (git config --global user.name / user.email) para crear commits.');throw e;}
async function commitPaths(root,paths,message){await git(root,['add','--all','--',...paths]);await git(root,['commit','-m',message]).catch(identityError);}
async function hasConflicts(root){return (await changes(root)).some(c=>c.status.includes('U')||['AA','DD'].includes(c.status));}
// Recent repositories live outside any repository so browser and desktop modes share them.
const homeFile=name=>path.join(process.env.GITDRIVE_HOME||path.join(process.env.APPDATA||os.homedir(),'GitDrive'),name);
async function readJson(name,fallback){return fs.readFile(homeFile(name),'utf8').then(JSON.parse,e=>{if(e.code==='ENOENT')return fallback;throw e;});}
async function writeJson(name,value){const file=homeFile(name);await fs.mkdir(path.dirname(file),{recursive:true});const tmp=file+'.'+randomUUID();await fs.writeFile(tmp,JSON.stringify(value,null,2),{flag:'wx'});await fs.rename(tmp,file);}
const readWorkspaces=()=>readJson('workspaces.json',[]),writeWorkspaces=list=>writeJson('workspaces.json',list);
const defaultSettings={remindHours:4};
// Oldest modification among pending changes; deleted files fall back to the last commit time.
async function pendingSince(root,changed){
 if(!changed.length)return null;
 const last=+(await git(root,['log','-1','--format=%ct']).catch(()=> '0')).trim()*1000||Date.now();
 const times=await Promise.all(changed.slice(0,500).map(c=>fs.lstat(path.join(root,c.path)).then(s=>Math.max(s.mtimeMs,last),()=>last)));
 return new Date(Math.min(...times)).toISOString();
}
async function globalConfig(key){return (await git(os.homedir(),['config','--global','--get',key],{allowExit1:true}).catch(()=> '')).trim();}
const sameRoot=(x,y)=>x.toLowerCase()===y.toLowerCase();
async function branchName(root,name) {if(!name || name.startsWith('-'))throw Error('Nombre de rama inválido.'); await git(root,['check-ref-format','--branch',name]);}
export async function dispatch(action, a={}) {
 if(action==='remoteCheck') {
  if(typeof a.url!=='string'||!a.url.trim()||a.url.startsWith('-')||a.url.startsWith('ext::'))throw Error('URL inválida.');
  await git(await fs.realpath(a.root||process.cwd()),['ls-remote','--symref','--',a.url,'HEAD']);return true;
 }
 if(action==='clone') {
  if(typeof a.url!=='string'||!a.url.trim()||a.url.startsWith('-')||a.url.startsWith('ext::'))throw Error('URL inválida.');
  const dest=await fs.realpath(a.root);if((await fs.readdir(dest)).length)throw Error('Elige una carpeta vacía para clonar.');
  await git(dest,['clone','--',a.url,'.']);return {root:dest};
 }
 if(action==='workspaces') {
  const list=await readWorkspaces();
  return Promise.all(list.map(async w=>{
   if(!(await fs.stat(path.join(w.root,'.git')).then(()=>true,()=>false)))return {...w,missing:true,pending:0,pendingSince:null};
   const changed=await changes(w.root).catch(()=>[]);
   return {...w,missing:false,pending:changed.length,pendingSince:await pendingSince(w.root,changed)};
  })).then(l=>l.sort((x,y)=>Number(!!y.pinned)-Number(!!x.pinned)||y.lastOpened.localeCompare(x.lastOpened)));
 }
 if(action==='identity')return {name:await globalConfig('user.name'),email:await globalConfig('user.email')};
 if(action==='identitySet') {
  const name=String(a.name||'').trim(),email=String(a.email||'').trim();
  if(!name||/[\r\n<>]/.test(name))throw Error('Escribe un nombre válido.');
  if(!/^[^\s@<>]+@[^\s@<>]+$/.test(email))throw Error('Escribe un correo válido.');
  await git(os.homedir(),['config','--global','user.name',name]);await git(os.homedir(),['config','--global','user.email',email]);return {name,email};
 }
 if(action==='settings')return {...defaultSettings,...await readJson('settings.json',{})};
 if(action==='settingsSet') {
  const hours=Number(a.remindHours);if(!Number.isFinite(hours)||hours<0||hours>168)throw Error('Elige un intervalo entre 0 y 168 horas.');
  const settings={...defaultSettings,...await readJson('settings.json',{}),remindHours:hours};await writeJson('settings.json',settings);return settings;
 }
 if(action==='workspaceForget'||action==='workspacePin') {
  if(typeof a.path!=='string')throw Error('Ruta inválida.');
  const list=await readWorkspaces();
  await writeWorkspaces(action==='workspaceForget'?list.filter(w=>!sameRoot(w.root,a.path)):list.map(w=>sameRoot(w.root,a.path)?{...w,pinned:!!a.pinned}:w));return true;
 }
 if(action==='init') {
  const root=await fs.realpath(a.root);if(!(await fs.stat(root)).isDirectory())throw Error('Selecciona una carpeta.');
  const top=(await git(root,['rev-parse','--show-toplevel']).catch(()=> '')).trim();
  if(top)throw Error(sameRoot(path.resolve(top),root)?'Esta carpeta ya es un repositorio. Usa Abrir repositorio.':'Esta carpeta está dentro de otro repositorio: '+path.resolve(top));
  await git(root,['init','-b','main']);
  const name=(await git(root,['config','user.name']).catch(()=> '')).trim(),email=(await git(root,['config','user.email']).catch(()=> '')).trim();
  if(!name||!email)return {root,initialCommit:null,warning:'Repositorio creado sin commit inicial: configura tu nombre y correo de Git.'};
  // The first commit captures whatever the folder already contains, named after the folder and date.
  const message=`${path.basename(root)} · ${stamp(new Date(),false)}`;
  await git(root,['add','--all']);await git(root,['commit','--allow-empty','-m',message]);
  return {root,initialCommit:message};
 }
 const root=await rootOf(a.root);
 if(action.startsWith('sync'))return syncDispatch(action,a,root,{git,safe});
 if(action==='save') {
  const p=await safe(root,a.path);const stat=await fs.lstat(p);if(!stat.isFile()||stat.nlink>1)throw Error('No se puede editar este archivo o enlace.');
  const previous=await fs.readFile(p);if(previous.toString('utf8')!==a.original)throw Error('El archivo cambió fuera del editor. Ciérralo y vuelve a abrirlo para evitar sobrescribir cambios.');
  if(typeof a.content!=='string'||Buffer.byteLength(a.content)>512000)throw Error('El editor admite hasta 500 KB.');
  const tmp=p+'.gitdrive-'+randomUUID();try{await fs.writeFile(tmp,a.content,{flag:'wx',mode:stat.mode});await fs.rename(tmp,p);}finally{await fs.unlink(tmp).catch(()=>{});}return true;
 }
 if(action==='snapshot') {
  const branch=(await git(root,['symbolic-ref','--quiet','--short','HEAD']).catch(()=> 'HEAD separado')).trim();
  const branches=(await git(root,['for-each-ref','--format=%(refname:short)','refs/heads'])).trim().split('\n').filter(Boolean);
  const remote=(await git(root,['remote','get-url','origin']).catch(()=> '')).trim();
  const upstream=(await git(root,['rev-parse','--abbrev-ref','@{upstream}']).catch(()=> '')).trim();
  const counts=upstream?(await git(root,['rev-list','--left-right','--count','HEAD...@{upstream}'])).trim().split(/\s+/):['0','0'];
  const history=(await git(root,['log','-20','--format=%h%x1f%s%x1f%an%x1f%ar']).catch(()=> '')).trim().split('\n').filter(Boolean).map(x=>{const [hash,message,author,date]=x.split('\x1f');return {hash,message,author,date};});
  const changed=await changes(root);
  return {root,branch,branches,remote,upstream,ahead:+counts[0],behind:+counts[1],changes:changed,pendingSince:await pendingSince(root,changed),history};
 }
 if(action==='list') {
  const dir=await safe(root,a.path||'',true); const entries=await fs.readdir(dir,{withFileTypes:true});
  return Promise.all(entries.filter(e=>e.name.toLowerCase()!=='.git').sort((a,b)=>Number(b.isDirectory())-Number(a.isDirectory())||a.name.localeCompare(b.name)).map(async e=>{const stat=await fs.lstat(path.join(dir,e.name));return {name:e.name,path:[a.path,e.name].filter(Boolean).join('/'),directory:e.isDirectory(),link:e.isSymbolicLink(),size:stat.size,modified:stat.mtime.toISOString()};}));
 }
 if(action==='read') {const p=await safe(root,a.path);const stat=await fs.stat(p);if(stat.size>512000)throw Error('Vista previa limitada a 500 KB.');const data=await fs.readFile(p);if(data.includes(0))throw Error('Archivo binario: vista previa no disponible.');return data.toString('utf8');}
 if(action==='create') {const p=await safe(root,a.path);if(a.directory)await fs.mkdir(p);else await fs.writeFile(p,a.content||'',{flag:'wx'});return true;}
 if(action==='rename') {const from=await safe(root,a.path),to=await safe(root,a.to);if(await fs.lstat(to).then(()=>true,()=>false))throw Error('El destino ya existe.');await fs.rename(from,to);return true;}
 if(action==='trash') {
  const from=await safe(root,a.path); const gitDir=(await git(root,['rev-parse','--absolute-git-dir'])).trim(); const id=randomUUID(); const dir=path.join(gitDir,'gitdrive-trash',id);await fs.mkdir(dir,{recursive:true});
  await fs.writeFile(path.join(dir,'metadata.json'),JSON.stringify({path:a.path}));await fs.rename(from,path.join(dir,'content'));return {id,path:a.path};
 }
 if(action==='restore') {
  if(!/^[a-f0-9-]{36}$/.test(a.id))throw Error('Identificador inválido.');const gitDir=(await git(root,['rev-parse','--absolute-git-dir'])).trim();const dir=path.join(gitDir,'gitdrive-trash',a.id);const meta=JSON.parse(await fs.readFile(path.join(dir,'metadata.json'),'utf8'));const target=await safe(root,meta.path);if(await fs.lstat(target).then(()=>true,()=>false))throw Error('El destino ya existe.');await fs.rename(path.join(dir,'content'),target);await fs.rm(dir,{recursive:true});return true;
 }
 if(action==='trashList') {const gitDir=(await git(root,['rev-parse','--absolute-git-dir'])).trim(); const dir=path.join(gitDir,'gitdrive-trash');return Promise.all((await fs.readdir(dir).catch(()=>[])).map(async id=>({id,...JSON.parse(await fs.readFile(path.join(dir,id,'metadata.json'),'utf8'))})));}
 if(action==='branchCreate') {await clean(root);await branchName(root,a.name);await git(root,['switch','-c',a.name]);return true;}
 if(action==='branchSwitch') {await clean(root);await branchName(root,a.name);await git(root,['switch',a.name]);return true;}
 if(action==='branchDelete') {await branchName(root,a.name);await git(root,['branch','-d',a.name]);return true;}
 if(action==='diff') {await safe(root,a.path);return await git(root,['diff','HEAD','--',a.path]).catch(()=>git(root,['diff','--',a.path]));}
 if(action==='workspaceTouch') {
  const gitDir=(await git(root,['rev-parse','--absolute-git-dir'])).trim();
  const external=(await fs.readFile(path.join(gitDir,'gitdrive-sync.json'),'utf8').then(JSON.parse,()=>null))?.external||'';
  const remote=(await git(root,['remote','get-url','origin']).catch(()=> '')).trim();
  const list=await readWorkspaces(),old=list.find(w=>sameRoot(w.root,root));
  const entry={root,name:path.basename(root),remote,external,lastOpened:new Date().toISOString(),pinned:!!old?.pinned};
  await writeWorkspaces([entry,...list.filter(w=>!sameRoot(w.root,root))].slice(0,50));return entry;
 }
 if(action==='commit') {
  const message=a.message?.trim()||autoMessage();
  const changed=await changes(root);if(changed.some(c=>c.status.includes('U')||['AA','DD'].includes(c.status)))throw Error('Resuelve los conflictos antes de crear un commit.');
  if(!Array.isArray(a.paths)||!a.paths.length)throw Error('Selecciona cambios.');
  if(changed.some(c=>c.status[0]!==' '&&c.status[0]!=='?'&&!a.paths.includes(c.path)))throw Error('Hay archivos preparados fuera de tu selección. Inclúyelos para conservar el índice.');
  const paths=[];for(const p of a.paths){await safe(root,p);const c=changed.find(c=>c.path===p);if(!c)throw Error('El estado cambió. Actualiza y vuelve a seleccionar.');paths.push(p);if(c.old){await safe(root,c.old);paths.push(c.old);}}
  await commitPaths(root,paths,message);return {message};
 }
 if(action==='backup') {
  // One click: commit every change (auto message when empty) and push when a remote exists.
  if(await hasConflicts(root))throw Error('Resuelve los conflictos antes de crear un respaldo.');
  let message=null;
  if((await changes(root)).length){message=a.message?.trim()||autoMessage();await git(root,['add','--all']);await git(root,['commit','-m',message]).catch(identityError);}
  const remote=(await git(root,['remote']).catch(()=> '')).split('\n').includes('origin');
  if(!remote)return {message,pushed:false};
  try{const name=(await git(root,['symbolic-ref','--short','HEAD'])).trim();await git(root,['push','--set-upstream','origin',name]);return {message,pushed:true};}
  catch(e){return {message,pushed:false,pushError:e.message};}
 }
 if(action==='remote') {if(typeof a.url!=='string'||!a.url.trim()||a.url.startsWith('-')||a.url.startsWith('ext::'))throw Error('URL inválida.');const existing=(await git(root,['remote'])).split('\n').includes('origin');await git(root,['remote',existing?'set-url':'add','origin',a.url]);return true;}
 if(action==='fetch') {await git(root,['fetch','origin']);return true;}
 if(action==='pull') {await clean(root);await git(root,['pull','--ff-only']);return true;}
 if(action==='push') {const name=(await git(root,['symbolic-ref','--short','HEAD'])).trim();await git(root,['push','--set-upstream','origin',name]);return true;}
 throw Error('Operación desconocida.');
}
