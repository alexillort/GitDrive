# GitDrive · MVP 0.1

Explorador Git local-first en React + TypeScript, con contenedor de escritorio Tauri 2. Interfaz en español. Operaciones reales sobre repositorios locales, sin cuentas ni servicios propios.

## Probar ahora en Windows

Requisitos: **Node.js 22 o posterior** y **Git for Windows**, disponibles en PATH.

Desde PowerShell, dentro de esta carpeta:

```powershell
npm.cmd install
npm.cmd run build
npm.cmd start
```

Abre http://127.0.0.1:4317. Este modo local usa exactamente el mismo motor que la aplicación Tauri. El servidor escucha exclusivamente en loopback, comprueba Host y Origin y requiere un token por sesión. Detén el proceso con Ctrl+C.

Pega la ruta absoluta de un repositorio existente. Para empezar desde cero, crea una carpeta vacía en Windows, pega su ruta y pulsa **Crear en carpeta vacía**. GitDrive no modifica la identidad global de Git. Si Git solicita identidad, configúrala para tu repositorio:

```powershell
git -C C:\Proyectos\mi-proyecto config user.name "Tu nombre"
git -C C:\Proyectos\mi-proyecto config user.email "tu-correo@example.com"
```

## Ejecutar como aplicación de escritorio Tauri

Instala los [requisitos oficiales de Tauri para Windows](https://v2.tauri.app/start/prerequisites/): Rust con toolchain MSVC, Microsoft C++ Build Tools con desarrollo de escritorio C++ y WebView2. Node.js y Git deben seguir instalados: este MVP usa un motor Node compartido, no los incluye en el instalador.

```powershell
npm.cmd install
npm.cmd run tauri dev
```

Para generar el instalador:

```powershell
npm.cmd run tauri build
```

El instalador se genera en `src-tauri/target/release/bundle/nsis/`. Esta entrega incluye el código de Tauri; su compilación nativa no se validó en el entorno de desarrollo porque Rust y las herramientas C++ no estaban disponibles. No se entrega un .exe precompilado.

## Recorrido de prueba

1. Abre un repositorio de prueba o inicializa una carpeta vacía.
2. Crea un archivo desde GitDrive; edítalo con tu editor habitual. Actualiza o vuelve a enfocar GitDrive.
3. Abre **Cambios**, selecciona el archivo, escribe un mensaje y crea un commit. Compruébalo en **Historial**.
4. Crea una rama con el botón + del panel lateral. Haz otro commit y vuelve a la rama anterior: los archivos cambian con la rama.
5. Renombra un archivo o muévelo indicando una ruta relativa cuyo directorio exista.
6. Elimina un archivo escribiendo ELIMINAR. Abre **Papelera** y restáuralo.
7. Conecta un remoto `origin` HTTPS, SSH o un repositorio bare local. **Subir** publica la rama; **Consultar** ejecuta fetch; **Bajar** admite únicamente fast-forward.

## Alcance y seguridad

- Navegación de carpetas, búsqueda en la carpeta actual, previsualización de texto hasta 500 KB y diferencias Git.
- Crear archivos/carpetas, renombrar y mover sin sobrescribir; papelera persistente dentro del directorio Git. No se purga automáticamente.
- Creación/cambio de ramas solo con árbol limpio. Borrado con `git branch -d`, sin forzar. Un repositorio sin commits debe guardar su primer commit antes de crear ramas.
- Commits sobre los cambios seleccionados. Si ya hay otros archivos preparados en el índice, exige incluirlos para evitar commits accidentales. Los hooks de Git y la firma configurada se respetan; un error conserva los archivos preparados.
- Las rutas no pueden salir de la raíz, acceder a `.git` ni atravesar enlaces simbólicos. No gestiona submódulos, enlaces ni repositorios anidados de forma especializada.
- Las operaciones se serializan por proceso de la aplicación. No abras varias instancias para escribir simultáneamente sobre el mismo repositorio; otras herramientas pueden modificarlo y el estado se verifica nuevamente antes del commit.
- El borrado solo afecta al árbol de trabajo; se debe crear un commit para registrar la eliminación en Git. La papelera no es un respaldo y no se sincroniza.
- Autenticación mediante Git Credential Manager o SSH ya configurados. No almacena contraseñas. Las operaciones remotas tienen un tiempo límite de dos minutos.
- Sin fuerza, reset, rebase automático, resolución de conflictos ni mezcla automática. Si las ramas divergen, Git rechaza Bajar y conserva los cambios.
- Sin clonación, editor integrado, selector nativo de carpetas ni observación continua. Abre clones existentes; refresca al recuperar el foco o con el botón de actualizar.
- Sincronización significa Git fetch/pull/push manual. No replica carpetas arbitrarias como Dropbox. No incluye archivos ignorados en la lista de cambios, aunque sí los muestra en el explorador.
- Abre repositorios de confianza: Git puede ejecutar hooks y programas definidos en la configuración del repositorio.

## Estructura y verificación

`src/`: interfaz. `backend/engine.mjs`: motor Git y archivos; ejecución sin shell. `backend/server.mjs`: modo local. `backend/cli.mjs`: protocolo JSON por entrada/salida estándar para Tauri. `src-tauri/`: ventana nativa y puente Rust serializado.

```powershell
npm.cmd test
npm.cmd run build
```

Las pruebas usan repositorios temporales reales, incluyendo un remoto bare. Cubren commits seleccionados, índices preparados, bloqueo de cambios de rama, borrado de ramas sin integrar, rutas peligrosas, recuperación y push/fetch/pull.
